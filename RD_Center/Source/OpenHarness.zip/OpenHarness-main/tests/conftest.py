"""Shared test fixtures."""
